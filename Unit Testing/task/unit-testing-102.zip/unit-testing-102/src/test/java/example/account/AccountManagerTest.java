package example.account;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AccountManagerTest {
    AccountManager accountManager=new AccountManagerImpl();
    @Test
    void givenCustomerWithEnoughBalance_whenWithdraw_thenSuccess() {
        // Arrange
        Customer customer = new Customer();
        customer.setBalance(100);

        // Act
        String result = accountManager.withdraw(customer,30);

        // Assert
        Assertions.assertEquals("success",result);
        Assertions.assertEquals(70,customer.getBalance());
    }




}
